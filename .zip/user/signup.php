<?php
require_once('../_path.php');
$current_menu = '로그인' ;
$side_contents = require_once(SKIN_DIR .'/menu_sub.php') ;
require_once(SKIN_DIR . '/layout2.php'); 
require_once(YOGI_DIR . '/user.signup.php'); 
require_once(SKIN_DIR . '/footer.php'); 
?>



 

