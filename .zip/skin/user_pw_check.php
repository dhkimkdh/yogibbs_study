  <!-------- skin/user_pw_check.php 시작 ---------->
  <h5 class="mt-3">비밀번호 확인</h5>
  <form style="max-width: 500px" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
    <div class="form-group">
      <input type="password" class="form-control" name="pass" placeholder="본인 확인을 위해 비밀번호를 다시 한 번 입력하세요"/>
    </div>
    <div class="form-group">
      <input type="submit" value="확 인" name="submit1" />
    </div>
  </form>
  <!-------- skin/user_pw_check.php 끝 ---------->
